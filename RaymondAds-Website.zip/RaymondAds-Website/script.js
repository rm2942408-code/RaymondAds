const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuToggle.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(isOpen));
});
document.querySelectorAll('.nav a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
}));
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('contactForm');
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const name = String(data.get('name') || '').trim();
  const email = String(data.get('email') || '').trim();
  const service = String(data.get('service') || '').trim();
  const message = String(data.get('message') || '').trim();
  const subject = encodeURIComponent(`RaymondAds project enquiry — ${service}`);
  const body = encodeURIComponent(`Hello RaymondAds,\n\nMy name is ${name}.\nEmail: ${email}\nService needed: ${service}\n\nProject details:\n${message}\n\nThank you.`);
  const status = document.getElementById('formStatus');
  status.textContent = 'Opening your email app with your enquiry. If it does not open, email hello@raymondads.com directly.';
  window.location.href = `mailto:hello@raymondads.com?subject=${subject}&body=${body}`;
});
