# RaymondAds Website

A responsive, single-page creative agency website for RaymondAds. It presents services for website design, advertising, graphic design, and logo/brand identity.

## Preview locally
1. Download and extract the ZIP.
2. Open `index.html` in a browser.

For a more realistic local development workflow, open the folder in Visual Studio Code and use the Live Server extension.

## Publish with GitHub Pages
1. Create a new repository on GitHub (for example, `raymondads-website`).
2. Upload `index.html`, `style.css`, `script.js`, and this README to the repository root.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**, select `main` and `/ (root)`, then save.
5. Wait for GitHub Pages to publish your website.

## Customize before publishing
- Replace `hello@raymondads.com` in `index.html` and `script.js` with your real business email.
- Update service details, portfolio concepts, and contact information to match your actual offers.
- The portfolio section contains sample concept mockups, not real client case studies.
- The contact form opens the visitor's email app using a `mailto:` link. It does not save submissions. For a live form that works without an email app, connect a form service or backend.
- Google Fonts are loaded online; system fallback fonts are included.

## Files
- `index.html` — website content and page structure
- `style.css` — layout, visual design, and responsive styling
- `script.js` — mobile navigation, current year, and contact form behavior
